Standard policies: Reference and API
====================================
.. toctree::
   :maxdepth: 2

   policy-adjustable-royalty.rst
   policy-auction-sale.rst
   policy-blacklist.rst
   policy-collection.rst
   policy-disable-burn.rst
   policy-disable-transfer.rst
   policy-disable-sale.rst
   policy-dutch-auction-sale.rst
   policy-extra-policies.rst
   policy-fixed-issuance.rst
   policy-fixed-sale.rst
   policy-guards.rst
   policy-instant-mint.rst
   policy-marketplace.rst
   policy-non-fungible.rst
   policy-royalty.rst
   policy-trusted-custody.rst
