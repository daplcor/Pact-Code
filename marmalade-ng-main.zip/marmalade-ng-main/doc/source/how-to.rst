How to
======

These of how-to s are only basic suggestion on how to use Marlmade-NG.
They can be seen as a starting point.

They cover less than 20% of the features allowed by Marmalade-NG and Pact.

.. toctree::
   :maxdepth: 2

   how-to-create-token.rst
   how-to-wallets.rst
   how-to-marketplaces.rst
   how-to-custom-policy.rst
