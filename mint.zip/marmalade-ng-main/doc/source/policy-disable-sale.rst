.. _POLICY-DISABLE-SALE:

policy-disable-sale
-------------------

Description
^^^^^^^^^^^

This policy prohibits the token from being sold using the sale defpact.


Implemented hooks
^^^^^^^^^^^^^^^^^

.. code:: lisp

  (defun enforce-salle-offer)



Input data structures
^^^^^^^^^^^^^^^^^^^^^
Nope

External functions
^^^^^^^^^^^^^^^^^^
Nope

View functions
^^^^^^^^^^^^^^
Nope
